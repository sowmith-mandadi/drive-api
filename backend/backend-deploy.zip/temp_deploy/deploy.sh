#!/bin/bash
# Deploy script for App Engine

echo "Deploying dispatch rules..."
gcloud app deploy dispatch.yaml --quiet

echo "Deploying application..."
gcloud app deploy app.yaml --quiet

echo "Deployment complete. Your application should be accessible at:"
echo "https://conference-cms-project.uw.r.appspot.com"
echo "https://conference-cms-project.uw.r.appspot.com/docs"
echo "https://conference-cms-project.uw.r.appspot.com/api/docs"
echo "https://conference-cms-project.uw.r.appspot.com/health" 