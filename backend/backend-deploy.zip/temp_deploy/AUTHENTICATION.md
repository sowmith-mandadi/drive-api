# Authentication in Google App Engine

This document describes how authentication is handled in the application, particularly for Google App Engine deployment.

## Authentication Overview

When running in Google App Engine, the application uses **Application Default Credentials (ADC)** to authenticate with Google Cloud services like Firestore. This means the application automatically uses the service account that's attached to the App Engine instance.

## How Authentication Works

Google's Authentication libraries search for credentials in the following order:

1. `GOOGLE_APPLICATION_CREDENTIALS` environment variable pointing to a service account key file
2. User credentials from `gcloud auth application-default login`
3. The attached service account credentials (via the metadata server)

In App Engine, the third method is used - the application automatically uses the App Engine default service account to authenticate.

## Important Environment Variables

- `GAE_APPLICATION`: Set by App Engine to indicate the application is running in App Engine
- `GAE_ENV`: Set to "standard" when running in App Engine standard environment
- `GOOGLE_CLOUD_PROJECT`: The Google Cloud project ID
- `GOOGLE_APPLICATION_CREDENTIALS`: If set, points to a service account key file
- `USE_APP_ENGINE_CREDENTIALS`: When set to "true", forces using App Engine's default credentials

## Troubleshooting Authentication Issues

If you encounter authentication issues, try the following steps:

### 1. Check Environment Detection

Make sure the application correctly detects it's running in App Engine. In logs, look for:

```
Detected App Engine environment
```

### 2. Check Project ID

Verify the correct project ID is being used:

```
Using App Engine default credentials with project ID: [your-project-id]
```

### 3. Check Authentication Method

The application should be using App Engine default credentials:

```
Initialized Firestore client with App Engine default credentials
```

### 4. Credential File Conflicts

If you've set `GOOGLE_APPLICATION_CREDENTIALS` but it's not working in App Engine, try:

- Setting it to an empty string in app.yaml: `GOOGLE_APPLICATION_CREDENTIALS: ""`
- Setting `USE_APP_ENGINE_CREDENTIALS: "true"` in app.yaml

### 5. Common Errors

- `DefaultCredentialsError`: Indicates the application couldn't find credentials. In App Engine, this usually means the application is attempting to use a local credentials file that doesn't exist.
- `Permission denied`: The App Engine service account might lack necessary IAM permissions. Check IAM roles for the App Engine default service account.

### 6. Running the Diagnostic Script

The application includes a diagnostic script that checks authentication. You can see its output in the logs or by running:

```
python diagnose.py
```

### 7. Local Development vs App Engine

For local development, you may need to:
- Run `gcloud auth application-default login` to set up local credentials
- Set the `GOOGLE_APPLICATION_CREDENTIALS` environment variable to a service account key file
- Use the Firestore emulator: `export FIRESTORE_EMULATOR_HOST=localhost:8080`

## Service Account Permissions

The App Engine default service account needs the following permissions:
- Firestore Data Editor (`roles/datastore.user`)
- Firestore User (`roles/datastore.user`)
- Any other permissions required by your application

## Best Practices

1. Never store service account key files in your code repository
2. Use the App Engine default service account when possible instead of explicit key files
3. Follow the principle of least privilege - grant only necessary permissions
4. Always monitor logs for authentication errors
5. Regularly review and rotate service account credentials if using key files 