# CSV Import Guide for Content Management System

This guide explains how to use the CSV import template for batch uploading content to the system.

## Required Fields

The following fields are required:
- `sessionId` - Unique identifier for the session (used to prevent duplicates)
- `title` - Title of the content

## Recommended Fields

For optimal content display, these fields are recommended:
- `description` - Brief description of the content
- `abstract` - Longer description/summary of the content
- `status` - Status of the content (e.g., "Published", "Scheduled", "Draft")
- `sessionType` - Type of session (e.g., "Workshop", "Presentation")
- `track` - Primary category/track

## Field Mappings

### Content Metadata
- `sessionId` → Unique identifier for the session
- `title` → Content title
- `description` → Brief description
- `abstract` → Longer detailed abstract
- `status` → Content status ("Published", "Scheduled", "Draft", etc.)
- `sessionType` → Type of session
- `demoType` → Type of demo
- `sessionDate` → Date of the session (YYYY-MM-DD format)
- `durationMinutes` → Duration in minutes
- `learningLevel` → Learning level ("Beginner", "Intermediate", "Advanced")
- `track` → Primary track/category
- `jobRoles` → Comma-separated list of job roles (will be converted to array)
- `areasOfInterest` → Comma-separated list of areas of interest (will be converted to array)
- `industry` → Industry
- `tags` → Comma-separated list of tags (will be converted to array)
- `source` → Source of content (default: "upload")

### URLs & Media
- `presentationSlidesUrl` → URL to presentation slides
- `recapSlidesUrl` → URL to recap slides
- `driveLink` → Google Drive link
- `videoRecordingStatus` → Status of video recording ("Available", "Pending", etc.)
- `videoYoutubeUrl` → URL to YouTube video

### YouTube Information
- `ytVideoTitle` → Title for YouTube video
- `ytDescription` → Description for YouTube video

### Presenters
For each presenter (up to 6), the following fields are available:
- `presenterFullName{n}` → Presenter's full name
- `presenterJobTitle{n}` → Presenter's job title
- `presenterCompany{n}` → Presenter's company
- `presenterType{n}` → Type of presenter (e.g., "Partner", "Consultant", "Government")
- `presenterIndustry{n}` → Presenter's industry
- `presenterRegion{n}` → Presenter's region

Replace `{n}` with a number from 1-6 (e.g., `presenterFullName1`, `presenterJobTitle1`, etc.)

## CSV Format Example

The first row of your CSV file should contain the field names, and subsequent rows should contain the data:

```
sessionId,title,description,...
"SESSION-001","Content Title","Description text",...
```

## Notes on Field Formats

- Text fields should be enclosed in double quotes if they contain commas, line breaks, or quotes
- Lists (like tags) can be provided as comma-separated values: "tag1,tag2,tag3"
- Dates should be in YYYY-MM-DD format
- Empty fields can be left blank

## Importing the CSV

Use the API endpoint `/api/batch/upload` to upload your CSV file:

```
curl -X POST http://localhost:8000/api/batch/upload \
  -F "file=@content_import_template_with_drive.csv"
```

The system will check for duplicate `sessionId` values and will not import content that already exists with the same ID. 