# Deploying the Backend in Google Cloud Shell

This guide explains how to use the `backend-deploy.zip` file to deploy your application in Google Cloud Shell.

## Prerequisites

- Google Cloud Platform account with billing enabled
- App Engine enabled in your project
- Appropriate permissions to deploy to App Engine

## Deployment Steps

### 1. Upload the ZIP File

1. Open [Google Cloud Shell](https://shell.cloud.google.com/)
2. Click the three-dot menu and select "Upload"
3. Choose `backend-deploy.zip` from your local machine
4. Wait for the upload to complete

### 2. Extract and Set Up

```bash
# Extract the ZIP file
unzip backend-deploy.zip

# Navigate to the extracted directory
cd temp_deploy

# Make the setup script executable (if needed)
chmod +x run_cloud_shell.sh

# Run the setup script
./run_cloud_shell.sh
```

The script will:
- Create a virtual environment
- Install all required dependencies
- Detect your Python version and use compatible packages
- Set up upload directories
- Start the development server to test

### 3. Deploy to App Engine

Once you've verified everything works in the development server, deploy to App Engine:

```bash
# Set your GCP project (replace YOUR-PROJECT-ID with your actual project ID)
gcloud config set project YOUR-PROJECT-ID

# Deploy the application to App Engine
gcloud app deploy app.yaml --project=YOUR-PROJECT-ID
```

### 4. Optional Configuration

If your application requires environment variables, set them up:

```bash
# Set environment variables in app.yaml
nano app.yaml

# Add environment variables under env_variables section
# For example:
# env_variables:
#   GOOGLE_CLIENT_ID: "your-client-id"
#   GOOGLE_CLIENT_SECRET: "your-client-secret"
```

### Troubleshooting

- If you encounter package compatibility issues, check the script outputs and error messages
- For Python 3.12+, the script will automatically patch `config.py` for compatibility
- If deployment fails, check the logs using `gcloud app logs tail` 