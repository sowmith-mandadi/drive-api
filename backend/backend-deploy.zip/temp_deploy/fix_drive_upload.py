#!/usr/bin/env python3
"""
Wrapper script to fix JWT token date issues when running test_drive_upload.py
"""

import os
import sys
import time
from unittest.mock import patch
from datetime import datetime

# This is the key fix - we're going to patch time.time() to return the current date
# instead of your system's incorrect date (which is in 2025)
def fixed_time():
    # Get current time based on a known fixed date (May 6, 2023)
    # This avoids the future date issue that's causing the JWT signature error
    return 1683410730  # This is May 6, 2023 time

if __name__ == "__main__":
    # Path the time.time function in the google auth library
    with patch('time.time', fixed_time):
        # Import test_drive_upload module
        sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
        
        # Run the test_drive_upload script with the same arguments
        import test_drive_upload
        
        print("\n⚠️ Running with patched time to fix JWT signature issues\n")
        
        # Pass the command line arguments to the test_drive_upload.py script
        sys.argv = [sys.argv[0]] + sys.argv[1:]
        
        # Run the process_drive_file function directly with arguments
        from test_drive_upload import process_drive_file
        
        # Parse arguments
        import argparse
        parser = argparse.ArgumentParser(description="Fix JWT date issues when testing Google Drive upload")
        parser.add_argument("file_id", help="Google Drive file ID to upload")
        parser.add_argument("--service-account-path", help="Path to the service account key file")
        parser.add_argument("--title", help="Title for the content")
        parser.add_argument("--description", help="Description for the content")
        
        args = parser.parse_args()
        
        # Set environment variables for service account
        if args.service_account_path:
            os.environ["GOOGLE_SERVICE_ACCOUNT_PATH"] = args.service_account_path
            os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = args.service_account_path
        
        # Process the file
        success = process_drive_file(args.file_id, args.title, args.description)
        
        # Exit with appropriate code
        sys.exit(0 if success else 1) 