#!/usr/bin/env python
"""
Script to check for duplicate sessionIds in the Firestore database.
Useful for debugging and verifying the duplicate detection functionality.
"""

import argparse
import os
import sys
from typing import List, Dict, Any

# Add backend directory to path so we can import app modules
sys.path.append(os.path.abspath('.'))

try:
    from app.db.firestore_client import FirestoreClient
    from app.core.logging import configure_logging
except ImportError:
    print("Error: Unable to import required modules.")
    print("Make sure you're running this script from the backend directory.")
    sys.exit(1)

# Setup logging
logger = configure_logging()

def check_session_id(session_id: str) -> List[Dict[str, Any]]:
    """
    Check if a sessionId exists in the database.
    
    Args:
        session_id: Session ID to check
        
    Returns:
        List of documents with the given sessionId
    """
    firestore = FirestoreClient()
    filters = [("sessionId", "==", session_id)]
    results = firestore.list_documents("content", limit=10, filters=filters)
    return results

def list_duplicate_session_ids() -> Dict[str, List[Dict[str, Any]]]:
    """
    Find all duplicate sessionIds in the database.
    
    Returns:
        Dictionary mapping sessionIds to lists of documents
    """
    firestore = FirestoreClient()
    
    # Get all content items (up to a reasonable limit)
    all_content = firestore.list_documents("content", limit=1000)
    
    # Group by sessionId
    session_map = {}
    for content in all_content:
        session_id = content.get("sessionId")
        if session_id:
            if session_id not in session_map:
                session_map[session_id] = []
            session_map[session_id].append(content)
    
    # Filter for duplicates (more than one document with the same sessionId)
    duplicates = {sid: docs for sid, docs in session_map.items() if len(docs) > 1}
    
    return duplicates

def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(description="Check for duplicate sessionIds in Firestore.")
    parser.add_argument("--session-id", help="Specific sessionId to check")
    parser.add_argument("--list-all", action="store_true", help="List all duplicate sessionIds")
    parser.add_argument("--verbose", action="store_true", help="Show detailed document info")
    
    args = parser.parse_args()
    
    if args.session_id:
        # Check specific sessionId
        print(f"Checking for sessionId: {args.session_id}")
        results = check_session_id(args.session_id)
        
        if not results:
            print(f"No documents found with sessionId: {args.session_id}")
        else:
            print(f"Found {len(results)} document(s) with sessionId: {args.session_id}")
            for doc in results:
                if args.verbose:
                    print(f"  Document ID: {doc.get('id')}")
                    print(f"  Title: {doc.get('title')}")
                    print(f"  Created: {doc.get('createdAt')}")
                    print("  ---")
                else:
                    print(f"  {doc.get('id')} - {doc.get('title')}")
    
    elif args.list_all:
        # List all duplicates
        print("Searching for duplicate sessionIds...")
        duplicates = list_duplicate_session_ids()
        
        if not duplicates:
            print("No duplicate sessionIds found.")
        else:
            print(f"Found {len(duplicates)} duplicate sessionIds:")
            for sid, docs in duplicates.items():
                print(f"\nSessionId: {sid} ({len(docs)} documents)")
                for doc in docs:
                    if args.verbose:
                        print(f"  Document ID: {doc.get('id')}")
                        print(f"  Title: {doc.get('title')}")
                        print(f"  Created: {doc.get('createdAt')}")
                        print("  ---")
                    else:
                        print(f"  {doc.get('id')} - {doc.get('title')}")
    
    else:
        parser.print_help()

if __name__ == "__main__":
    main() 